# Customer Behavior Dashboard

This is a browser-openable static reconstruction of the original Power BI dashboard.

## Open on a laptop
Double-click `index.html` or open it with Chrome/Edge/Firefox.

## GitHub
Upload `index.html` to a repository. To publish it as a website, enable **GitHub Pages** for the repository.

The original Power BI `.pbix` is also preserved separately; this HTML version is intended for easy laptop viewing and GitHub hosting.
